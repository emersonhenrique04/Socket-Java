package com.tekcreek.socketprg.groupchat.commons;

public interface Command {
	int JOIN = 1;
	int MESSAGE = 2;
	int LEAVE = 3;
}
